""" This is so it is recognized as a django app
"""