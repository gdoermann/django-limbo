# -*- coding: utf-8 -*-
# just to be reconized as django app
